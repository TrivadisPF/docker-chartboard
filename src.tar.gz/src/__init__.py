VERSION = (2, 0, 6)
__version__ = '.'.join(str(num) for num in VERSION)
